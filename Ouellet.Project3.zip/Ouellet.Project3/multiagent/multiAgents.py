# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

import random
from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        #weights used in the evaluation function
        w1 = 100
        w2 = 10
        w3 = 100
        w4 = -500

        #pieces of eval function
        f1 = w1 * (1/(len(newFood.asList())+1)) #lower food count = better
        f2 = w2 * newScaredTimes[0] #if a ghost is scared more = better

        rand = random.randint(0,10) #this block assigns f3 | Assigns a 1/10 chance to pick a random action (prevents thrashing)
        if rand == 3:
            f3 = 100
        else:
            try: #need try block to prevent dividing by 0
                f3 = w3 * (1/min([manhattanDistance(newPos, food) for food in newFood.asList()])) #close food = better
            except:
                f3 = 500 #only one more dot, so we want to get to it asap

        x_pacman, y_pacman = newPos
        for ghostState in newGhostStates: #assign f4 according to where the ghost is with respect to pacman
            x_ghost, y_ghost = ghostState.getPosition()
            if x_pacman == x_ghost or y_pacman == y_ghost:
                f4 = w4 * 1 #pacman NEVER wants to be in a state with the ghost so huge cost if a ghost is in the next state, also helps to move pacman around the board
                break
            else:
                f4 = w4 * (1/(-500)) #if no ghost, f4 evaluates to 1
        return f1 + f2 + f3 + f4


def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """

        def minimax_helper(depth, evaluationFunction):

            def max_node(gameState, curr_depth):
                if gameState.isWin() or gameState.isLose() or curr_depth == self.depth:
                    return evaluationFunction(gameState), {}
                max_nodes = [float('-inf')] #need this so that max() arg can never be empty
                max_nodes_actions = {} #dictionary for actions
                max_nodes_actions[float('-inf')] = "" #prevents key error
                for actions in gameState.getLegalActions(0):
                    successor_gameState = gameState.generateSuccessor(0, actions)
                    max_nodes.append(min_node(successor_gameState, curr_depth, 1)[0]) #append the value of the min node
                    max_nodes_actions[min_node(successor_gameState, curr_depth, 1)[0]] = actions #assign the value-action pair in a dictionary for later retrieval
                return max(max_nodes), max_nodes_actions[max(max_nodes)]

            def min_node(gameState, curr_depth, agent_index):
                if gameState.isWin() or gameState.isLose() or curr_depth == self.depth:
                    return evaluationFunction(gameState), {}
                min_nodes = []
                min_nodes_actions = {}
                for actions in gameState.getLegalActions(agent_index):
                    successor_gameState = gameState.generateSuccessor(agent_index, actions)
                    if agent_index == gameState.getNumAgents() - 1: #reached the end of a ply, go back to max nodes
                        min_nodes.append(max_node(successor_gameState, curr_depth + 1)[0]) #append the value of the max node
                        min_nodes_actions[max_node(successor_gameState, curr_depth + 1)[0]] = actions #assign the value-action pair
                    else: #continue on to the next min node, not at the end of ply yet (explicit else statment not necessary, but used it for nice allignment)
                        min_nodes.append(min_node(successor_gameState, curr_depth, agent_index+1)[0]) #append the value of the min node
                        min_nodes_actions[min_node(successor_gameState, curr_depth, agent_index+1)[0]] = actions #assign the v-a pair
                return min(min_nodes), min_nodes_actions[min(min_nodes)]

            return max_node(gameState, 0)[1]

        return minimax_helper(self.depth, self.evaluationFunction)

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        def alpha_beta_helper(depth, evaluationFunction):

            def max_node(gameState, curr_depth, alpha, beta):
                if gameState.isWin() or gameState.isLose() or curr_depth == self.depth:
                    return self.evaluationFunction(gameState), {}
                max_nodes = float('-inf')
                max_nodes_actions = ""
                for actions in gameState.getLegalActions(0):
                    successor_gameState = gameState.generateSuccessor(0, actions)
                    min_node_val = min_node(successor_gameState, curr_depth, 1,alpha,beta)[0] #assign this for readability
                    if min_node_val > max_nodes: #if block finds greastest value
                        max_nodes = min_node_val
                        max_nodes_actions = actions
                    if max_nodes > beta: #pruning check
                        return max_nodes, max_nodes_actions #assign the value-action pair in a dictionary for later retrieval
                    alpha = max(max_nodes, alpha) #assign best alpha
                return max_nodes, max_nodes_actions

            def min_node(gameState, curr_depth, agent_index, alpha,beta):
                if gameState.isWin() or gameState.isLose():
                    return self.evaluationFunction(gameState), ""
                min_nodes = float('inf')
                min_nodes_actions = ""
                for actions in gameState.getLegalActions(agent_index):
                    successor_gameState = gameState.generateSuccessor(agent_index, actions)

                    if agent_index == gameState.getNumAgents() - 1: #reached the end of a ply, go back to max nodes
                        max_node_val = max_node(successor_gameState, curr_depth + 1, alpha,beta)[0]  #assign this for readability
                        if max_node_val < min_nodes: #find lowest value
                            min_nodes = max_node_val
                            min_nodes_actions = actions
                        if min_nodes < alpha: #pruning check
                            return min_nodes, min_nodes_actions
                        beta = min(beta, min_nodes) #assign best beta
                    else: #continue on to the next min node, not at the end of ply yet (explicit else statment not necessary, just used it for nice allignment)
                        min_node_val = min_node(successor_gameState, curr_depth, agent_index+1, alpha,beta)[0] #assign this for readability
                        if min_node_val < min_nodes: #find lowest value
                            min_nodes = min_node_val
                            min_nodes_actions = actions
                        if min_nodes < alpha: #pruning check
                            return min_nodes, min_nodes_actions
                        beta = min(beta, min_nodes) #assign best beta
                return min_nodes, min_nodes_actions

            return max_node(gameState, 0, float('-inf'), float('inf'))[1]

        return alpha_beta_helper(self.depth, self.evaluationFunction)

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        def expectimax_helper(depth, evaluationFunction): #exact same code as minimax, except we return the (sum of all the nodes / len of nodes) in the min node

            def max_node(gameState, curr_depth):
                if gameState.isWin() or gameState.isLose() or curr_depth == self.depth:
                    return evaluationFunction(gameState), {}
                max_nodes = [float('-inf')]
                max_nodes_actions = {}
                max_nodes_actions[float('-inf')] = "EMPTY"
                for actions in gameState.getLegalActions(0):
                    successor_gameState = gameState.generateSuccessor(0, actions)
                    max_nodes.append(min_node(successor_gameState, curr_depth, 1)[0]) #append the value of the min node
                    max_nodes_actions[min_node(successor_gameState, curr_depth, 1)[0]] = actions #assign the value-action pair in a dictionary for later retrieval
                return max(max_nodes), max_nodes_actions[max(max_nodes)]

            def min_node(gameState, curr_depth, agent_index):
                if gameState.isWin() or gameState.isLose() or curr_depth == self.depth:
                    return evaluationFunction(gameState), {}
                min_nodes = []
                for actions in gameState.getLegalActions(agent_index):
                    successor_gameState = gameState.generateSuccessor(agent_index, actions)
                    if agent_index == gameState.getNumAgents() - 1: #reached the end of a ply, go back to max nodes
                        min_nodes.append(max_node(successor_gameState, curr_depth + 1)[0]) #append the value of the max node
                    else: #continue on to the next min node, not at the end of ply yet (explicit else statment not necessary, just used it for nice allignment)
                        min_nodes.append(min_node(successor_gameState, curr_depth, agent_index+1)[0]) #append the value of the min node
                return sum(min_nodes) / len(gameState.getLegalActions(agent_index)), "placeholder"

            return max_node(gameState, 0)[1]

        return expectimax_helper(self.depth, self.evaluationFunction)

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    def manhatten_dist_to_pacman(ghost_location): #finds the manhattan distance to pacman (needed a one arg function for map).
        pacman_location = currentGameState.getPacmanPosition()
        return manhattanDistance(pacman_location, ghost_location)
    def closest_food(food_location): #finds the smallest distrance to a food pellet from pacman (needed a one arg function for map).
        pacman_location = currentGameState.getPacmanPosition()
        return manhattanDistance(pacman_location, food_location)

    manhatten_distance_sum_to_all_ghosts = sum(list(map(manhatten_dist_to_pacman, currentGameState.getGhostPositions())))
    get_closest_food = min(list(map(closest_food, currentGameState.getCapsules())))

    f1 = manhatten_distance_sum_to_all_ghosts #sum of all manhatten distance to ghosts
    f2 = (1/(currentGameState.getNumFood()+1)) #reciprocal of the num of remaining food (less food = better)
    f3 = (1/(get_closest_food+1)) #reciprocal of nearest food pellet (pacman gets closer to food = better)
    
    return 1*f1 + 500*f2 + 1*f3


# Abbreviation
better = betterEvaluationFunction
