# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()

def depthFirstSearch(problem):
    frontier = util.Stack()
    history = util.Counter()
    path_storage = {}

    start_node = problem.getStartState()
    frontier.push((start_node,'Start', 0))
    path_storage[start_node] = [] #This makes sure that the for loop does not produce a key error when creating the solution of the parent and successor nodes.
    history = []

    while frontier.isEmpty() == False:
        curr_node = frontier.pop()
        if curr_node not in history:
            history.append(curr_node[0])
            if problem.isGoalState(curr_node[0]) == True:
                return path_storage[curr_node[0]]
            for successor in problem.getSuccessors(curr_node[0]): #pushes the successor tuples onto the frontier if not already in history
                if successor[0] not in history: #Checks to see if the state has been seen before, if not: visit it
                    frontier.push(successor)
                    path_storage[successor[0]] = path_storage[curr_node[0]] + [successor[1]] #Continually updates the path of the solution by pulling the previous solution and adding the current states direction to it
    raise StopIteration("The frontier is EMPTY. The search has failed to find a solution.")

def breadthFirstSearch(problem):
    frontier = util.Queue()
    history = util.Counter()
    path_storage = {}

    start_node = problem.getStartState()
    frontier.push((start_node,'Start', 0))
    path_storage[start_node] = [] #This makes sure that the for loop does not produce a key error when creating the solution of the parent and successor nodes.
    history = []

    while frontier.isEmpty() == False:
        curr_node = frontier.pop()
        if curr_node not in history:
            history.append(curr_node[0])
            if problem.isGoalState(curr_node[0]) == True:
                return path_storage[curr_node[0]]
            for successor in problem.getSuccessors(curr_node[0]): #pushes the successor tuples onto the frontier if not already in history
                if successor[0] not in history: #Checks to see if the state has been seen before, if not: visit it
                    frontier.push(successor)
                    history.append(successor[0])
                    path_storage[successor[0]] = path_storage[curr_node[0]] + [successor[1]] #Continually updates the path of the solution by pulling the previous solution and adding the current states direction to it
    raise StopIteration("The frontier is EMPTY. The search has failed to find a solution.")

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    frontier = util.PriorityQueue()
    history = util.Counter()
    path_storage = {}

    start_node = problem.getStartState()
    frontier.push((start_node,'Start', 0), problem.getCostOfActions([])) #push first state with an empty cost value
    path_storage[start_node] = [] #This makes sure that the for loop does not produce a key error when creating the solution of the parent and successor nodes.
    history[start_node] = 0 #initializes memory 

    while frontier.isEmpty() == False:
        curr_node = frontier.pop()

        if problem.isGoalState(curr_node[0]) == True:
            return path_storage[curr_node[0]]
        for successor in problem.getSuccessors(curr_node[0]): #pushes the successor tuples onto the frontier if not already in history
            if successor[0] not in history.keys(): #Checks to see if the state has been seen before, if not: visit it
                frontier.push(successor, problem.getCostOfActions(path_storage[curr_node[0]] + [successor[1]]))
                history[successor[0]] += successor[2]
                path_storage[successor[0]] = path_storage[curr_node[0]] + [successor[1]] #Continually updates the path of the solution by pulling the previous solution and adding the current states direction to it
            elif problem.getCostOfActions(path_storage[curr_node[0]] + [successor[1]]) < history[successor[0]]: #This line checks the states that we have already seen to see if our current path is cheaper than one that we have already found, in that case replace that one with this cheaper version.
                frontier.push(successor, problem.getCostOfActions(path_storage[curr_node[0]] + [successor[1]]))
                history[successor[0]] = successor[2] #changes the cost in history to the cheaper version that we found
                path_storage[successor[0]] = path_storage[curr_node[0]] + [successor[1]]
    raise StopIteration("The frontier is EMPTY. The search has failed to find a solution.")

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
